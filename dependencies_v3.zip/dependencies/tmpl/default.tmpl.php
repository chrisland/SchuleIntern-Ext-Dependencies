<div class="box">
	<div class="box-body">
		<div id="app">Content aus der Example Extension:</div>
        <br>
        <p><?= $data ?></p>
	</div>
</div>